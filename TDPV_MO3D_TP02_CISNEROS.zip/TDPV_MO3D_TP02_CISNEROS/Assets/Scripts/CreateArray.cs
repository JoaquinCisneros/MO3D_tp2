using UnityEngine;

public class CreateArray : MonoBehaviour
{
    // El prefab que se usar� como bloque de construcci�n
    public GameObject blockPrefab;

    // Dimensiones del muro (filas y columnas)
    public int N = 5; // N�mero de filas (eje Y)
    public int M = 5; // N�mero de columnas (eje X)

    // Start se ejecuta al inicio del juego
    void Start()
    {
        GenerateWall();
    }

    // Funci�n para generar el muro
    void GenerateWall()
    {
        // Verifica si se asign� un prefab
        if (blockPrefab == null)
        {
            Debug.LogError("No se ha asignado un prefab para los bloques.");
            return;
        }

        // Obtener todos los renderers del prefab y sus hijos (porque son los renderers de las figuras dentro del gameobject prefab)
        Renderer[] renderers = blockPrefab.GetComponentsInChildren<Renderer>();

        if (renderers.Length == 0)
        {
            Debug.LogError("El prefab o sus hijos no contienen ning�n Renderer para calcular el tama�o del objeto.");
            return;
        }

        // Calcular los l�mites combinados del prefab (si se toma un solo bounds, las esferas son superpuestas por los cubos)
        Bounds combinedBounds = renderers[0].bounds;
        foreach (Renderer renderer in renderers)
        {
            combinedBounds.Encapsulate(renderer.bounds);
        }

        // Tama�o total del prefab
        Vector3 blockSize = combinedBounds.size;

        // Usar el tama�o combinado del prefab para calcular el espaciado
        float blockSpacingX = blockSize.x;
        float blockSpacingY = blockSize.y;

        // Loop para generar el muro NxM
        for (int y = 0; y < N; y++) // Filas (eje Y)
        {
            for (int x = 0; x < M; x++) // Columnas (eje X)
            {
                // Calcula la posici�n del bloque en base a los �ndices x e y y su tama�o
                Vector3 position = new Vector3(x * blockSpacingX, y * blockSpacingY, 0);

                // Instancia el bloque en la posici�n calculada
                Instantiate(blockPrefab, position, Quaternion.identity);
            }
        }
    }
}


